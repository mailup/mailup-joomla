DROP TABLE IF EXISTS `#__mailup_subscriber`;
DROP TABLE IF EXISTS `#__mailup_listsub`;
DROP TABLE IF EXISTS `#__mailup_list`;
DROP TABLE IF EXISTS `#__mailup_groupsub`;
DROP TABLE IF EXISTS `#__mailup_group`;
